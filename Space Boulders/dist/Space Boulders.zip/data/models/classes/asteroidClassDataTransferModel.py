class AsteroidClassDataTransferModel:
    def __init__(self, base_vel, point_value, asteroid_image, size, asteroid_number):
        self.base_vel = base_vel
        self.point_value = point_value
        self.asteroid_image = asteroid_image
        self.size = size
        self.asteroid_number = asteroid_number
