class ShipsCollisionsDataModel:
    def __init__(self, ship, asteroids_sets, ufo_projectiles):
        self.ship = ship
        self.asteroids_sets = asteroids_sets
        self.ufo_projectiles = ufo_projectiles
