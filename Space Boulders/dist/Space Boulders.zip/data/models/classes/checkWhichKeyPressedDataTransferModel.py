class CheckWhichKeyPressedDataTransferModel:
    def __init__(self, ship, last_hyper_space_time, last_projectile_time, projectiles):
        self.ship = ship
        self.last_hyper_space_time = last_hyper_space_time
        self.last_projectile_time = last_projectile_time
        self.projectiles = projectiles
