class UfoUpdateDataModel:
    def __init__(self, ufo, last_ufo_time):
        self.ufo = ufo
        self.last_ufo_time = last_ufo_time
